﻿namespace SengYangBuildingSuppliesInvoiceProject
{
    partial class frmBuildingSuppliesInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTwoBySixLumber = new System.Windows.Forms.Label();
            this.lblTwoByFourLumber = new System.Windows.Forms.Label();
            this.lblFourByEightByHalfPlywood = new System.Windows.Forms.Label();
            this.lblFourByEightByFiveEigthsPlywood = new System.Windows.Forms.Label();
            this.lblThreeFourthNails = new System.Windows.Forms.Label();
            this.lblTwoHalfBrads = new System.Windows.Forms.Label();
            this.lblOneHalfGalScrews = new System.Windows.Forms.Label();
            this.lblSledgeHammer = new System.Windows.Forms.Label();
            this.lblDrillBits = new System.Windows.Forms.Label();
            this.lblStapleGun = new System.Windows.Forms.Label();
            this.lblTenLengthLabel = new System.Windows.Forms.Label();
            this.lblTwelveLengthLabel = new System.Windows.Forms.Label();
            this.lblOneSheetLabel = new System.Windows.Forms.Label();
            this.lblOneSheetLabelTwo = new System.Windows.Forms.Label();
            this.lblFivePoundBoxLabel = new System.Windows.Forms.Label();
            this.lblTenPoundBoxLabel = new System.Windows.Forms.Label();
            this.lblOnePoundBoxLabel = new System.Windows.Forms.Label();
            this.lblOneLabel = new System.Windows.Forms.Label();
            this.lblOnePackLabel = new System.Windows.Forms.Label();
            this.lblOneLabelTwo = new System.Windows.Forms.Label();
            this.lblTwoBySixPrice = new System.Windows.Forms.Label();
            this.lblTwoByFourPrice = new System.Windows.Forms.Label();
            this.lblFourByEightHalfPrice = new System.Windows.Forms.Label();
            this.lblFourByEightFiveEigthsPrice = new System.Windows.Forms.Label();
            this.lblNailsPrice = new System.Windows.Forms.Label();
            this.lblBradsPrice = new System.Windows.Forms.Label();
            this.lblScrewPrice = new System.Windows.Forms.Label();
            this.lblSledgeHammerPrice = new System.Windows.Forms.Label();
            this.lblDrillBitsPrice = new System.Windows.Forms.Label();
            this.lblStapleGunPrice = new System.Windows.Forms.Label();
            this.txtTwoBySixQuantity = new System.Windows.Forms.TextBox();
            this.txtTwoByFourQuantity = new System.Windows.Forms.TextBox();
            this.txtFourByEightHalfPlyQuantity = new System.Windows.Forms.TextBox();
            this.txtFourByEightFiveEigthsPlyQuantity = new System.Windows.Forms.TextBox();
            this.txtNailsQuantity = new System.Windows.Forms.TextBox();
            this.txtBradsQuantity = new System.Windows.Forms.TextBox();
            this.txtScrewsQuantity = new System.Windows.Forms.TextBox();
            this.txtHammerQuantity = new System.Windows.Forms.TextBox();
            this.txtDrillBitsQuantity = new System.Windows.Forms.TextBox();
            this.txtStapleGunQuantity = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblQuantityLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUnitLabel = new System.Windows.Forms.Label();
            this.lblItemLabel = new System.Windows.Forms.Label();
            this.lblTotalLabel = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblSubtotalLabel = new System.Windows.Forms.Label();
            this.lblSubtotal = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTwoBySixLumber
            // 
            this.lblTwoBySixLumber.AutoSize = true;
            this.lblTwoBySixLumber.Location = new System.Drawing.Point(109, 46);
            this.lblTwoBySixLumber.Name = "lblTwoBySixLumber";
            this.lblTwoBySixLumber.Size = new System.Drawing.Size(100, 17);
            this.lblTwoBySixLumber.TabIndex = 0;
            this.lblTwoBySixLumber.Text = "2\" x 6\" Lumber";
            // 
            // lblTwoByFourLumber
            // 
            this.lblTwoByFourLumber.AutoSize = true;
            this.lblTwoByFourLumber.Location = new System.Drawing.Point(109, 77);
            this.lblTwoByFourLumber.Name = "lblTwoByFourLumber";
            this.lblTwoByFourLumber.Size = new System.Drawing.Size(100, 17);
            this.lblTwoByFourLumber.TabIndex = 1;
            this.lblTwoByFourLumber.Text = "2\" x 4\" Lumber";
            // 
            // lblFourByEightByHalfPlywood
            // 
            this.lblFourByEightByHalfPlywood.AutoSize = true;
            this.lblFourByEightByHalfPlywood.Location = new System.Drawing.Point(70, 108);
            this.lblFourByEightByHalfPlywood.Name = "lblFourByEightByHalfPlywood";
            this.lblFourByEightByHalfPlywood.Size = new System.Drawing.Size(139, 17);
            this.lblFourByEightByHalfPlywood.TabIndex = 2;
            this.lblFourByEightByHalfPlywood.Text = "4\' x 8\' x 1/2\" Plywood";
            // 
            // lblFourByEightByFiveEigthsPlywood
            // 
            this.lblFourByEightByFiveEigthsPlywood.AutoSize = true;
            this.lblFourByEightByFiveEigthsPlywood.Location = new System.Drawing.Point(70, 138);
            this.lblFourByEightByFiveEigthsPlywood.Name = "lblFourByEightByFiveEigthsPlywood";
            this.lblFourByEightByFiveEigthsPlywood.Size = new System.Drawing.Size(139, 17);
            this.lblFourByEightByFiveEigthsPlywood.TabIndex = 3;
            this.lblFourByEightByFiveEigthsPlywood.Text = "4\' x 8\' x 5/8\" Plywood";
            // 
            // lblThreeFourthNails
            // 
            this.lblThreeFourthNails.AutoSize = true;
            this.lblThreeFourthNails.Location = new System.Drawing.Point(141, 164);
            this.lblThreeFourthNails.Name = "lblThreeFourthNails";
            this.lblThreeFourthNails.Size = new System.Drawing.Size(68, 17);
            this.lblThreeFourthNails.TabIndex = 4;
            this.lblThreeFourthNails.Text = "3/4\" Nails";
            // 
            // lblTwoHalfBrads
            // 
            this.lblTwoHalfBrads.AutoSize = true;
            this.lblTwoHalfBrads.Location = new System.Drawing.Point(123, 194);
            this.lblTwoHalfBrads.Name = "lblTwoHalfBrads";
            this.lblTwoHalfBrads.Size = new System.Drawing.Size(86, 17);
            this.lblTwoHalfBrads.TabIndex = 5;
            this.lblTwoHalfBrads.Text = "2 1/2\" Brads";
            // 
            // lblOneHalfGalScrews
            // 
            this.lblOneHalfGalScrews.AutoSize = true;
            this.lblOneHalfGalScrews.Location = new System.Drawing.Point(47, 222);
            this.lblOneHalfGalScrews.Name = "lblOneHalfGalScrews";
            this.lblOneHalfGalScrews.Size = new System.Drawing.Size(162, 17);
            this.lblOneHalfGalScrews.TabIndex = 6;
            this.lblOneHalfGalScrews.Text = "1 1/2\" Galvanized Screw";
            // 
            // lblSledgeHammer
            // 
            this.lblSledgeHammer.AutoSize = true;
            this.lblSledgeHammer.Location = new System.Drawing.Point(70, 248);
            this.lblSledgeHammer.Name = "lblSledgeHammer";
            this.lblSledgeHammer.Size = new System.Drawing.Size(140, 17);
            this.lblSledgeHammer.TabIndex = 7;
            this.lblSledgeHammer.Text = "10lb Sledge Hammer";
            // 
            // lblDrillBits
            // 
            this.lblDrillBits.AutoSize = true;
            this.lblDrillBits.Location = new System.Drawing.Point(38, 278);
            this.lblDrillBits.Name = "lblDrillBits";
            this.lblDrillBits.Size = new System.Drawing.Size(172, 17);
            this.lblDrillBits.TabIndex = 8;
            this.lblDrillBits.Text = "Five Drill Bits 1/16\" - 5/16\"";
            // 
            // lblStapleGun
            // 
            this.lblStapleGun.AutoSize = true;
            this.lblStapleGun.Location = new System.Drawing.Point(130, 308);
            this.lblStapleGun.Name = "lblStapleGun";
            this.lblStapleGun.Size = new System.Drawing.Size(79, 17);
            this.lblStapleGun.TabIndex = 9;
            this.lblStapleGun.Text = "Staple Gun";
            // 
            // lblTenLengthLabel
            // 
            this.lblTenLengthLabel.AutoSize = true;
            this.lblTenLengthLabel.Location = new System.Drawing.Point(237, 46);
            this.lblTenLengthLabel.Name = "lblTenLengthLabel";
            this.lblTenLengthLabel.Size = new System.Drawing.Size(75, 17);
            this.lblTenLengthLabel.TabIndex = 10;
            this.lblTenLengthLabel.Text = "10\' Length";
            // 
            // lblTwelveLengthLabel
            // 
            this.lblTwelveLengthLabel.AutoSize = true;
            this.lblTwelveLengthLabel.Location = new System.Drawing.Point(237, 77);
            this.lblTwelveLengthLabel.Name = "lblTwelveLengthLabel";
            this.lblTwelveLengthLabel.Size = new System.Drawing.Size(75, 17);
            this.lblTwelveLengthLabel.TabIndex = 11;
            this.lblTwelveLengthLabel.Text = "12\' Length";
            // 
            // lblOneSheetLabel
            // 
            this.lblOneSheetLabel.AutoSize = true;
            this.lblOneSheetLabel.Location = new System.Drawing.Point(255, 108);
            this.lblOneSheetLabel.Name = "lblOneSheetLabel";
            this.lblOneSheetLabel.Size = new System.Drawing.Size(57, 17);
            this.lblOneSheetLabel.TabIndex = 12;
            this.lblOneSheetLabel.Text = "1 Sheet";
            // 
            // lblOneSheetLabelTwo
            // 
            this.lblOneSheetLabelTwo.AutoSize = true;
            this.lblOneSheetLabelTwo.Location = new System.Drawing.Point(255, 138);
            this.lblOneSheetLabelTwo.Name = "lblOneSheetLabelTwo";
            this.lblOneSheetLabelTwo.Size = new System.Drawing.Size(57, 17);
            this.lblOneSheetLabelTwo.TabIndex = 13;
            this.lblOneSheetLabelTwo.Text = "1 Sheet";
            // 
            // lblFivePoundBoxLabel
            // 
            this.lblFivePoundBoxLabel.AutoSize = true;
            this.lblFivePoundBoxLabel.Location = new System.Drawing.Point(258, 164);
            this.lblFivePoundBoxLabel.Name = "lblFivePoundBoxLabel";
            this.lblFivePoundBoxLabel.Size = new System.Drawing.Size(54, 17);
            this.lblFivePoundBoxLabel.TabIndex = 14;
            this.lblFivePoundBoxLabel.Text = "5lb Box";
            // 
            // lblTenPoundBoxLabel
            // 
            this.lblTenPoundBoxLabel.AutoSize = true;
            this.lblTenPoundBoxLabel.Location = new System.Drawing.Point(250, 194);
            this.lblTenPoundBoxLabel.Name = "lblTenPoundBoxLabel";
            this.lblTenPoundBoxLabel.Size = new System.Drawing.Size(62, 17);
            this.lblTenPoundBoxLabel.TabIndex = 15;
            this.lblTenPoundBoxLabel.Text = "10lb Box";
            // 
            // lblOnePoundBoxLabel
            // 
            this.lblOnePoundBoxLabel.AutoSize = true;
            this.lblOnePoundBoxLabel.Location = new System.Drawing.Point(258, 220);
            this.lblOnePoundBoxLabel.Name = "lblOnePoundBoxLabel";
            this.lblOnePoundBoxLabel.Size = new System.Drawing.Size(54, 17);
            this.lblOnePoundBoxLabel.TabIndex = 16;
            this.lblOnePoundBoxLabel.Text = "1lb Box";
            // 
            // lblOneLabel
            // 
            this.lblOneLabel.AutoSize = true;
            this.lblOneLabel.Location = new System.Drawing.Point(277, 248);
            this.lblOneLabel.Name = "lblOneLabel";
            this.lblOneLabel.Size = new System.Drawing.Size(35, 17);
            this.lblOneLabel.TabIndex = 17;
            this.lblOneLabel.Text = "One";
            // 
            // lblOnePackLabel
            // 
            this.lblOnePackLabel.AutoSize = true;
            this.lblOnePackLabel.Location = new System.Drawing.Point(261, 278);
            this.lblOnePackLabel.Name = "lblOnePackLabel";
            this.lblOnePackLabel.Size = new System.Drawing.Size(51, 17);
            this.lblOnePackLabel.TabIndex = 18;
            this.lblOnePackLabel.Text = "1 Pack";
            // 
            // lblOneLabelTwo
            // 
            this.lblOneLabelTwo.AutoSize = true;
            this.lblOneLabelTwo.Location = new System.Drawing.Point(277, 306);
            this.lblOneLabelTwo.Name = "lblOneLabelTwo";
            this.lblOneLabelTwo.Size = new System.Drawing.Size(35, 17);
            this.lblOneLabelTwo.TabIndex = 19;
            this.lblOneLabelTwo.Text = "One";
            // 
            // lblTwoBySixPrice
            // 
            this.lblTwoBySixPrice.AutoSize = true;
            this.lblTwoBySixPrice.Location = new System.Drawing.Point(350, 46);
            this.lblTwoBySixPrice.Name = "lblTwoBySixPrice";
            this.lblTwoBySixPrice.Size = new System.Drawing.Size(36, 17);
            this.lblTwoBySixPrice.TabIndex = 20;
            this.lblTwoBySixPrice.Text = "3.95";
            // 
            // lblTwoByFourPrice
            // 
            this.lblTwoByFourPrice.AutoSize = true;
            this.lblTwoByFourPrice.Location = new System.Drawing.Point(350, 77);
            this.lblTwoByFourPrice.Name = "lblTwoByFourPrice";
            this.lblTwoByFourPrice.Size = new System.Drawing.Size(36, 17);
            this.lblTwoByFourPrice.TabIndex = 21;
            this.lblTwoByFourPrice.Text = "2.75";
            // 
            // lblFourByEightHalfPrice
            // 
            this.lblFourByEightHalfPrice.AutoSize = true;
            this.lblFourByEightHalfPrice.Location = new System.Drawing.Point(350, 108);
            this.lblFourByEightHalfPrice.Name = "lblFourByEightHalfPrice";
            this.lblFourByEightHalfPrice.Size = new System.Drawing.Size(36, 17);
            this.lblFourByEightHalfPrice.TabIndex = 22;
            this.lblFourByEightHalfPrice.Text = "7.50";
            // 
            // lblFourByEightFiveEigthsPrice
            // 
            this.lblFourByEightFiveEigthsPrice.AutoSize = true;
            this.lblFourByEightFiveEigthsPrice.Location = new System.Drawing.Point(350, 136);
            this.lblFourByEightFiveEigthsPrice.Name = "lblFourByEightFiveEigthsPrice";
            this.lblFourByEightFiveEigthsPrice.Size = new System.Drawing.Size(36, 17);
            this.lblFourByEightFiveEigthsPrice.TabIndex = 23;
            this.lblFourByEightFiveEigthsPrice.Text = "8.50";
            // 
            // lblNailsPrice
            // 
            this.lblNailsPrice.AutoSize = true;
            this.lblNailsPrice.Location = new System.Drawing.Point(350, 164);
            this.lblNailsPrice.Name = "lblNailsPrice";
            this.lblNailsPrice.Size = new System.Drawing.Size(36, 17);
            this.lblNailsPrice.TabIndex = 24;
            this.lblNailsPrice.Text = "5.75";
            // 
            // lblBradsPrice
            // 
            this.lblBradsPrice.AutoSize = true;
            this.lblBradsPrice.Location = new System.Drawing.Point(350, 194);
            this.lblBradsPrice.Name = "lblBradsPrice";
            this.lblBradsPrice.Size = new System.Drawing.Size(36, 17);
            this.lblBradsPrice.TabIndex = 25;
            this.lblBradsPrice.Text = "6.95";
            // 
            // lblScrewPrice
            // 
            this.lblScrewPrice.AutoSize = true;
            this.lblScrewPrice.Location = new System.Drawing.Point(350, 220);
            this.lblScrewPrice.Name = "lblScrewPrice";
            this.lblScrewPrice.Size = new System.Drawing.Size(36, 17);
            this.lblScrewPrice.TabIndex = 26;
            this.lblScrewPrice.Text = "5.95";
            // 
            // lblSledgeHammerPrice
            // 
            this.lblSledgeHammerPrice.AutoSize = true;
            this.lblSledgeHammerPrice.Location = new System.Drawing.Point(342, 248);
            this.lblSledgeHammerPrice.Name = "lblSledgeHammerPrice";
            this.lblSledgeHammerPrice.Size = new System.Drawing.Size(44, 17);
            this.lblSledgeHammerPrice.TabIndex = 27;
            this.lblSledgeHammerPrice.Text = "17.95";
            // 
            // lblDrillBitsPrice
            // 
            this.lblDrillBitsPrice.AutoSize = true;
            this.lblDrillBitsPrice.Location = new System.Drawing.Point(350, 278);
            this.lblDrillBitsPrice.Name = "lblDrillBitsPrice";
            this.lblDrillBitsPrice.Size = new System.Drawing.Size(36, 17);
            this.lblDrillBitsPrice.TabIndex = 28;
            this.lblDrillBitsPrice.Text = "5.95";
            // 
            // lblStapleGunPrice
            // 
            this.lblStapleGunPrice.AutoSize = true;
            this.lblStapleGunPrice.Location = new System.Drawing.Point(350, 308);
            this.lblStapleGunPrice.Name = "lblStapleGunPrice";
            this.lblStapleGunPrice.Size = new System.Drawing.Size(36, 17);
            this.lblStapleGunPrice.TabIndex = 29;
            this.lblStapleGunPrice.Text = "8.95";
            // 
            // txtTwoBySixQuantity
            // 
            this.txtTwoBySixQuantity.Location = new System.Drawing.Point(423, 43);
            this.txtTwoBySixQuantity.Name = "txtTwoBySixQuantity";
            this.txtTwoBySixQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtTwoBySixQuantity.TabIndex = 1;
            this.txtTwoBySixQuantity.Text = "0";
            this.txtTwoBySixQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTwoByFourQuantity
            // 
            this.txtTwoByFourQuantity.Location = new System.Drawing.Point(423, 74);
            this.txtTwoByFourQuantity.Name = "txtTwoByFourQuantity";
            this.txtTwoByFourQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtTwoByFourQuantity.TabIndex = 2;
            this.txtTwoByFourQuantity.Text = "0";
            this.txtTwoByFourQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFourByEightHalfPlyQuantity
            // 
            this.txtFourByEightHalfPlyQuantity.Location = new System.Drawing.Point(423, 105);
            this.txtFourByEightHalfPlyQuantity.Name = "txtFourByEightHalfPlyQuantity";
            this.txtFourByEightHalfPlyQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtFourByEightHalfPlyQuantity.TabIndex = 3;
            this.txtFourByEightHalfPlyQuantity.Text = "0";
            this.txtFourByEightHalfPlyQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtFourByEightFiveEigthsPlyQuantity
            // 
            this.txtFourByEightFiveEigthsPlyQuantity.Location = new System.Drawing.Point(423, 133);
            this.txtFourByEightFiveEigthsPlyQuantity.Name = "txtFourByEightFiveEigthsPlyQuantity";
            this.txtFourByEightFiveEigthsPlyQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtFourByEightFiveEigthsPlyQuantity.TabIndex = 4;
            this.txtFourByEightFiveEigthsPlyQuantity.Text = "0";
            this.txtFourByEightFiveEigthsPlyQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNailsQuantity
            // 
            this.txtNailsQuantity.Location = new System.Drawing.Point(423, 161);
            this.txtNailsQuantity.Name = "txtNailsQuantity";
            this.txtNailsQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtNailsQuantity.TabIndex = 5;
            this.txtNailsQuantity.Text = "0";
            this.txtNailsQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBradsQuantity
            // 
            this.txtBradsQuantity.Location = new System.Drawing.Point(423, 189);
            this.txtBradsQuantity.Name = "txtBradsQuantity";
            this.txtBradsQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtBradsQuantity.TabIndex = 6;
            this.txtBradsQuantity.Text = "0";
            this.txtBradsQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtScrewsQuantity
            // 
            this.txtScrewsQuantity.Location = new System.Drawing.Point(423, 217);
            this.txtScrewsQuantity.Name = "txtScrewsQuantity";
            this.txtScrewsQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtScrewsQuantity.TabIndex = 7;
            this.txtScrewsQuantity.Text = "0";
            this.txtScrewsQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtHammerQuantity
            // 
            this.txtHammerQuantity.Location = new System.Drawing.Point(423, 245);
            this.txtHammerQuantity.Name = "txtHammerQuantity";
            this.txtHammerQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtHammerQuantity.TabIndex = 8;
            this.txtHammerQuantity.Text = "0";
            this.txtHammerQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDrillBitsQuantity
            // 
            this.txtDrillBitsQuantity.Location = new System.Drawing.Point(423, 275);
            this.txtDrillBitsQuantity.Name = "txtDrillBitsQuantity";
            this.txtDrillBitsQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtDrillBitsQuantity.TabIndex = 9;
            this.txtDrillBitsQuantity.Text = "0";
            this.txtDrillBitsQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStapleGunQuantity
            // 
            this.txtStapleGunQuantity.Location = new System.Drawing.Point(423, 303);
            this.txtStapleGunQuantity.Name = "txtStapleGunQuantity";
            this.txtStapleGunQuantity.Size = new System.Drawing.Size(69, 22);
            this.txtStapleGunQuantity.TabIndex = 10;
            this.txtStapleGunQuantity.Text = "0";
            this.txtStapleGunQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(221, 397);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(91, 32);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(221, 349);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(91, 34);
            this.btnCalculate.TabIndex = 11;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblQuantityLabel
            // 
            this.lblQuantityLabel.AutoSize = true;
            this.lblQuantityLabel.Location = new System.Drawing.Point(431, 11);
            this.lblQuantityLabel.Name = "lblQuantityLabel";
            this.lblQuantityLabel.Size = new System.Drawing.Size(61, 17);
            this.lblQuantityLabel.TabIndex = 42;
            this.lblQuantityLabel.Text = "Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(325, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 43;
            this.label1.Text = "Price/unit($)";
            // 
            // lblUnitLabel
            // 
            this.lblUnitLabel.AutoSize = true;
            this.lblUnitLabel.Location = new System.Drawing.Point(248, 11);
            this.lblUnitLabel.Name = "lblUnitLabel";
            this.lblUnitLabel.Size = new System.Drawing.Size(33, 17);
            this.lblUnitLabel.TabIndex = 44;
            this.lblUnitLabel.Text = "Unit";
            // 
            // lblItemLabel
            // 
            this.lblItemLabel.AutoSize = true;
            this.lblItemLabel.Location = new System.Drawing.Point(143, 11);
            this.lblItemLabel.Name = "lblItemLabel";
            this.lblItemLabel.Size = new System.Drawing.Size(34, 17);
            this.lblItemLabel.TabIndex = 45;
            this.lblItemLabel.Text = "Item";
            // 
            // lblTotalLabel
            // 
            this.lblTotalLabel.AutoSize = true;
            this.lblTotalLabel.Location = new System.Drawing.Point(342, 402);
            this.lblTotalLabel.Name = "lblTotalLabel";
            this.lblTotalLabel.Size = new System.Drawing.Size(44, 17);
            this.lblTotalLabel.TabIndex = 48;
            this.lblTotalLabel.Text = "Total:";
            // 
            // lblTotal
            // 
            this.lblTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblTotal.Location = new System.Drawing.Point(392, 402);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(100, 23);
            this.lblTotal.TabIndex = 49;
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSubtotalLabel
            // 
            this.lblSubtotalLabel.AutoSize = true;
            this.lblSubtotalLabel.Location = new System.Drawing.Point(322, 357);
            this.lblSubtotalLabel.Name = "lblSubtotalLabel";
            this.lblSubtotalLabel.Size = new System.Drawing.Size(64, 17);
            this.lblSubtotalLabel.TabIndex = 50;
            this.lblSubtotalLabel.Text = "Subtotal:";
            // 
            // lblSubtotal
            // 
            this.lblSubtotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblSubtotal.Location = new System.Drawing.Point(392, 355);
            this.lblSubtotal.Name = "lblSubtotal";
            this.lblSubtotal.Size = new System.Drawing.Size(100, 23);
            this.lblSubtotal.TabIndex = 51;
            this.lblSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(102, 349);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(91, 32);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // frmBuildingSuppliesInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 465);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblSubtotal);
            this.Controls.Add(this.lblSubtotalLabel);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblTotalLabel);
            this.Controls.Add(this.lblItemLabel);
            this.Controls.Add(this.lblUnitLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblQuantityLabel);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtStapleGunQuantity);
            this.Controls.Add(this.txtDrillBitsQuantity);
            this.Controls.Add(this.txtHammerQuantity);
            this.Controls.Add(this.txtScrewsQuantity);
            this.Controls.Add(this.txtBradsQuantity);
            this.Controls.Add(this.txtNailsQuantity);
            this.Controls.Add(this.txtFourByEightFiveEigthsPlyQuantity);
            this.Controls.Add(this.txtFourByEightHalfPlyQuantity);
            this.Controls.Add(this.txtTwoByFourQuantity);
            this.Controls.Add(this.txtTwoBySixQuantity);
            this.Controls.Add(this.lblStapleGunPrice);
            this.Controls.Add(this.lblDrillBitsPrice);
            this.Controls.Add(this.lblSledgeHammerPrice);
            this.Controls.Add(this.lblScrewPrice);
            this.Controls.Add(this.lblBradsPrice);
            this.Controls.Add(this.lblNailsPrice);
            this.Controls.Add(this.lblFourByEightFiveEigthsPrice);
            this.Controls.Add(this.lblFourByEightHalfPrice);
            this.Controls.Add(this.lblTwoByFourPrice);
            this.Controls.Add(this.lblTwoBySixPrice);
            this.Controls.Add(this.lblOneLabelTwo);
            this.Controls.Add(this.lblOnePackLabel);
            this.Controls.Add(this.lblOneLabel);
            this.Controls.Add(this.lblOnePoundBoxLabel);
            this.Controls.Add(this.lblTenPoundBoxLabel);
            this.Controls.Add(this.lblFivePoundBoxLabel);
            this.Controls.Add(this.lblOneSheetLabelTwo);
            this.Controls.Add(this.lblOneSheetLabel);
            this.Controls.Add(this.lblTwelveLengthLabel);
            this.Controls.Add(this.lblTenLengthLabel);
            this.Controls.Add(this.lblStapleGun);
            this.Controls.Add(this.lblDrillBits);
            this.Controls.Add(this.lblSledgeHammer);
            this.Controls.Add(this.lblOneHalfGalScrews);
            this.Controls.Add(this.lblTwoHalfBrads);
            this.Controls.Add(this.lblThreeFourthNails);
            this.Controls.Add(this.lblFourByEightByFiveEigthsPlywood);
            this.Controls.Add(this.lblFourByEightByHalfPlywood);
            this.Controls.Add(this.lblTwoByFourLumber);
            this.Controls.Add(this.lblTwoBySixLumber);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBuildingSuppliesInvoice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Building Supplies Invoice";
            this.Load += new System.EventHandler(this.frmBuildingSuppliesInvoice_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTwoBySixLumber;
        private System.Windows.Forms.Label lblTwoByFourLumber;
        private System.Windows.Forms.Label lblFourByEightByHalfPlywood;
        private System.Windows.Forms.Label lblFourByEightByFiveEigthsPlywood;
        private System.Windows.Forms.Label lblThreeFourthNails;
        private System.Windows.Forms.Label lblTwoHalfBrads;
        private System.Windows.Forms.Label lblOneHalfGalScrews;
        private System.Windows.Forms.Label lblSledgeHammer;
        private System.Windows.Forms.Label lblDrillBits;
        private System.Windows.Forms.Label lblStapleGun;
        private System.Windows.Forms.Label lblTenLengthLabel;
        private System.Windows.Forms.Label lblTwelveLengthLabel;
        private System.Windows.Forms.Label lblOneSheetLabel;
        private System.Windows.Forms.Label lblOneSheetLabelTwo;
        private System.Windows.Forms.Label lblFivePoundBoxLabel;
        private System.Windows.Forms.Label lblTenPoundBoxLabel;
        private System.Windows.Forms.Label lblOnePoundBoxLabel;
        private System.Windows.Forms.Label lblOneLabel;
        private System.Windows.Forms.Label lblOnePackLabel;
        private System.Windows.Forms.Label lblOneLabelTwo;
        private System.Windows.Forms.Label lblTwoBySixPrice;
        private System.Windows.Forms.Label lblTwoByFourPrice;
        private System.Windows.Forms.Label lblFourByEightHalfPrice;
        private System.Windows.Forms.Label lblFourByEightFiveEigthsPrice;
        private System.Windows.Forms.Label lblNailsPrice;
        private System.Windows.Forms.Label lblBradsPrice;
        private System.Windows.Forms.Label lblScrewPrice;
        private System.Windows.Forms.Label lblSledgeHammerPrice;
        private System.Windows.Forms.Label lblDrillBitsPrice;
        private System.Windows.Forms.Label lblStapleGunPrice;
        private System.Windows.Forms.TextBox txtTwoBySixQuantity;
        private System.Windows.Forms.TextBox txtTwoByFourQuantity;
        private System.Windows.Forms.TextBox txtFourByEightHalfPlyQuantity;
        private System.Windows.Forms.TextBox txtFourByEightFiveEigthsPlyQuantity;
        private System.Windows.Forms.TextBox txtNailsQuantity;
        private System.Windows.Forms.TextBox txtBradsQuantity;
        private System.Windows.Forms.TextBox txtScrewsQuantity;
        private System.Windows.Forms.TextBox txtHammerQuantity;
        private System.Windows.Forms.TextBox txtDrillBitsQuantity;
        private System.Windows.Forms.TextBox txtStapleGunQuantity;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblQuantityLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUnitLabel;
        private System.Windows.Forms.Label lblItemLabel;
        private System.Windows.Forms.Label lblTotalLabel;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblSubtotalLabel;
        private System.Windows.Forms.Label lblSubtotal;
        private System.Windows.Forms.Button btnClear;
    }
}

